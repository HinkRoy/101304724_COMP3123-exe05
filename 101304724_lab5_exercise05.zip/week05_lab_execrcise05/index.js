const express = require('express');
const app = express();
const router = express.Router();
const fs = require('fs');

// Load user data from user.json file
const userData = JSON.parse(fs.readFileSync('user.json'));

/*
- Create new html file name home.html 
- add <h1> tag with message "Welcome to ExpressJs Tutorial"
- Return home.html page to the client
*/
router.get('/home', (req, res) => {
  // Create the HTML response
  const htmlResponse = '<h1>Welcome to ExpressJs Tutorial</h1>';
  res.send(htmlResponse);
});

/*
- Return all details from user.json file to the client as JSON format
*/
router.get('/profile', (req, res) => {
  res.json(userData);
});

/*
- Modify /login router to accept username and password as query string parameters
- Read data from user.json file
- If username and password are valid then send response as below
    {
        status: true,
        message: "User is valid"
    }
- If the username is invalid then send a response as below
    {
        status: false,
        message: "Username is invalid"
    }
- If the password is invalid then send a response as below
    {
        status: false,
        message: "Password is invalid"
    }
*/
router.get('/login', (req, res) => {
  const { username, password } = req.query;
  
  if (!username || !password) {
    res.status(400).json({ status: false, message: "Username and password are required" });
    return;
  }
  
  if (username === userData.username && password === userData.password) {
    res.json({ status: true, message: "User is valid" });
  } else if (username !== userData.username) {
    res.json({ status: false, message: "Username is invalid" });
  } else {
    res.json({ status: false, message: "Password is invalid" });
  }
});

/*
- Modify /logout route to accept username as a parameter and display a message
    in HTML format like <b>${username} successfully logged out.</b>
*/
router.get('/logout/:username', (req, res) => {
  const { username } = req.params;
  const htmlResponse = `<b>${username} successfully logged out.</b>`;
  res.send(htmlResponse);
});

app.use('/', router);

app.listen(process.env.PORT || 8081, () => {
  console.log('Web Server is listening at port ' + (process.env.PORT || 8081));
});
